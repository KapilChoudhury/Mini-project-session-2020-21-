	<div class="footer">
		<div class="container">
			<p class="wow fadeInLeft" data-wow-delay="0.4s">&copy; Online Tiffin Service System &nbsp;</p>
		</div>
	</div>